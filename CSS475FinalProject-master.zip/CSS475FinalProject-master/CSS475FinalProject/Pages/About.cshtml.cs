using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Net;
using System.Net.Http;
using System.Text;

namespace CSS475FinalProject.Pages
{
    public class AboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
